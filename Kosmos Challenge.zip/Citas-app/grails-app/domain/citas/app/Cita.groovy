package citas.app

class Cita {
    Doctor doct
    Consultorio cnstr
    int horario
    String paciente

    static constraints = {
    }
}
