package citas.app

class Doctor {
    String Nombre
    String Apellido_Paterno
    String Apellido_Materno
    String Especialidad

    static constraints = {
    }
}
