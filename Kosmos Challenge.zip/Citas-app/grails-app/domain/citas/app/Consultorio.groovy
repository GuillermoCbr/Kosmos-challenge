package citas.app

class Consultorio {
    int Numero
    int Piso

    static constraints = {
    }
}
