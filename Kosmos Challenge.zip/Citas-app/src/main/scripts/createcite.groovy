description "Example description", "grails example-usage"

println "Example Script"
 Doctor D = new Doctor
 D.Nombre = Julio
 D.Apellido_Materno = Urias
 D.Apellido_Paterno = Hernandez